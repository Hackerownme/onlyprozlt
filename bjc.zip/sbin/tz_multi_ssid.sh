#!/bin/sh



CONFIG_ROOT_DIR="/mnt/userdata/etc_rw/wifi/realtek/rtl8192c"

TZ_SSID2_ENABLE=`nv get tz_ssid2_enable`
TZ_SSID3_ENABLE=`nv get tz_ssid3_enable`
TZ_SSID4_ENABLE=`nv get tz_ssid4_enable`
TZ_MULTIDHCP_ENABLE=`nv get tz_multidhcp_enable`
TZ_DHCP2_ENABLE=`nv get tz_dhcp2_enable`
TZ_DHCP3_ENABLE=`nv get tz_dhcp3_enable`
TZ_DHCP4_ENABLE="0"
TZ_MAINSSID_ENABLE=`nv get wifiEnabled`


va0_netmask=`nv get va0_netmask`
va0_ipaddr=`nv get va0_ipaddr`
va1_netmask=`nv get va1_netmask`
va1_ipaddr=`nv get va1_ipaddr`


eap_set_paras() {
	TZ_HOTSPOT_ENABLE=`nv get hotspot_enable`
	TZ_EAP_ENABLE=`nv get hotspot_eap_enable`
	TZ_EAP_RADIUS_IP=`nv get hotspot_eap_radius_ip`
	TZ_EAP_RADIUS_PORT=`nv get hotspot_eap_radius_port`
	TZ_EAP_RADIUS_SECRET=`nv get hotspot_eap_radius_secret`

	if [ "${TZ_HOTSPOT_ENABLE}" = "1" ] && [ "${TZ_EAP_ENABLE}" = "1" ]; then
		echo "<<<  eap_set_paras   >>>"
		echo 2 > $CONFIG_ROOT_DIR/$1/encrypt
		echo 1 > $CONFIG_ROOT_DIR/$1/wep
		echo 3 > $CONFIG_ROOT_DIR/$1/wpa2_cipher
		echo 1 > $CONFIG_ROOT_DIR/$1/wpa_auth
		echo 2 > $CONFIG_ROOT_DIR/$1/wpa_cipher
		echo 34 > $CONFIG_ROOT_DIR/$1/wsc_auth
		echo 0 > $CONFIG_ROOT_DIR/$1/wsc_disabled
		echo 12 > $CONFIG_ROOT_DIR/$1/wsc_enc
		#echo $TZ_EAP_RADIUS_IP > $CONFIG_ROOT_DIR/$1/rs_ip
		#echo $TZ_EAP_RADIUS_PORT > $CONFIG_ROOT_DIR/$1/rs_port
		echo "127.0.0.1" > $CONFIG_ROOT_DIR/$1/rs_ip
		echo 1818 > $CONFIG_ROOT_DIR/$1/rs_port
		echo $TZ_EAP_RADIUS_SECRET > $CONFIG_ROOT_DIR/$1/rs_password
	fi
}

multissid_set_paras() {
echo "<<<  multissid_set_paras $1   >>>"
echo 0 > $CONFIG_ROOT_DIR/$1/wlan_disabled
iwpriv wlan0 set_mib vap_enable=1

if [ $1 = "wlan0-va0" ]; then
	SSID=`nv get SSID2`
	HideSSID=`nv get HideSSID2`
	EncrypType=`nv get EncrypType2`
	WPAPSK=`nv get WPAPSK2`
	MAX_Access_num=`nv get MAX_Access_num2`
	AuthMode=`nv get AuthMode2`
	EncrypType=`nv get EncrypType2`
	DefaultKeyID=`nv get S2_DefaultKeyID`
	if [ -n "$DefaultKeyID" ]; then
		SSID_index=`expr $DefaultKeyID + 1`
		Keytpye=`nv get S2_Key"$SSID_index"Type`
		KeyStrl=`nv get S2_Key"$SSID_index"Str1`
	fi
elif [ $1 = "wlan0-va1" ]; then
	SSID=`nv get SSID3`
	HideSSID=`nv get HideSSID3`
	EncrypType=`nv get EncrypType3`
	WPAPSK=`nv get WPAPSK3`
	MAX_Access_num=`nv get MAX_Access_num3`
	AuthMode=`nv get AuthMode3`
	EncrypType=`nv get EncrypType3`
	DefaultKeyID=`nv get S3_DefaultKeyID`
	if [ -n "$DefaultKeyID" ]; then
		SSID_index=`expr $DefaultKeyID + 1`
		Keytpye=`nv get S3_Key"$SSID_index"Type`
		KeyStrl=`nv get S3_Key"$SSID_index"Str1`
	fi
elif [ $1 = "wlan0-va2" ]; then
	SSID=`nv get SSID4`
	HideSSID=`nv get HideSSID4`
	EncrypType=`nv get EncrypType4`
	WPAPSK=`nv get WPAPSK4`
	MAX_Access_num=`nv get MAX_Access_num4`
	AuthMode=`nv get AuthMode4`
	EncrypType=`nv get EncrypType4`
	DefaultKeyID=`nv get S4_DefaultKeyID`
	if [ -n "$DefaultKeyID" ]; then
		SSID_index=`expr $DefaultKeyID + 1`
		Keytpye=`nv get S4_Key"$SSID_index"Type`
		KeyStrl=`nv get S4_Key"$SSID_index"Str1`
	fi
fi

echo "$SSID" > $CONFIG_ROOT_DIR/$1/ssid
echo "$HideSSID" > $CONFIG_ROOT_DIR/$1/hidden_ssid
echo "$MAX_Access_num" > $CONFIG_ROOT_DIR/$1/supported_sta_num

if [ "${AuthMode}" = "OPEN" ]; then
	if [ "${EncrypType}" = "WEP" ]; then #wep参数不全，还要进一步添加
		
		echo "1" > $CONFIG_ROOT_DIR/$1/encrypt
		echo "$DefaultKeyID" > $CONFIG_ROOT_DIR/$1/wep_default_key
		echo "0" > $CONFIG_ROOT_DIR/$1/auth_type
		if [ "$Keytpye" = "0" ]; then #hex key
			echo "1" > $CONFIG_ROOT_DIR/$1/wep_key_type 
			if [ "${#KeyStrl}" = "10" ]; then
				echo "1" > $CONFIG_ROOT_DIR/$1/wep
				echo $KeyStrl > $CONFIG_ROOT_DIR/$1/wepkey"$SSID_index"_64_hex
			elif [ "${#KeyStrl}" = "26" ]; then
				echo "2" > $CONFIG_ROOT_DIR/$1/wep
				echo $KeyStrl > $CONFIG_ROOT_DIR/$1/wepkey"$SSID_index"_128_hex
			fi
		else #ascii key
			echo "0" > $CONFIG_ROOT_DIR/$1/wep_key_type 
			if [ "${#KeyStrl}" = "5" ]; then
				echo "1" > $CONFIG_ROOT_DIR/$1/wep
				echo $KeyStrl | od -N5 -t x1 |head -1|sed -e 's/0000000//g' -e 's/ //g'|tr -d '\n' > $CONFIG_ROOT_DIR/$1/wepkey"$SSID_index"_64_asc
			elif [ "${#KeyStrl}" = "13" ]; then
				echo "2" > $CONFIG_ROOT_DIR/$1/wep
				echo $KeyStrl | od -N13 -t x1 |head -1|sed -e 's/0000000//g' -e 's/ //g'|tr -d '\n' > $CONFIG_ROOT_DIR/$1/wepkey"$SSID_index"_128_asc
			fi
		fi
	else
		echo "0" > $CONFIG_ROOT_DIR/$1/encrypt
		echo "0" > $CONFIG_ROOT_DIR/$1/psk_enable
		echo "0" > $CONFIG_ROOT_DIR/$1/enable_1x			
		echo "0" > $CONFIG_ROOT_DIR/$1/auth_type
	fi		
elif [ "${AuthMode}" = "WPA2PSK" ]; then
	echo "4" > $CONFIG_ROOT_DIR/$1/encrypt
	echo "0" > $CONFIG_ROOT_DIR/$1/enable_1x	
	echo "2" > $CONFIG_ROOT_DIR/$1/auth_type	
	if [ "${EncrypType}" = "AES" ]; then
		echo "0" > $CONFIG_ROOT_DIR/$1/wpa_cipher	
		echo "2" > $CONFIG_ROOT_DIR/$1/wpa2_cipher
	elif [ "${EncrypType}" = "TKIP" ]; then
		echo "0" > $CONFIG_ROOT_DIR/$1/wpa_cipher	
		echo "1" > $CONFIG_ROOT_DIR/$1/wpa2_cipher
	elif [ "${EncrypType}" = "TKIPAES" ]; then
		echo "0" > $CONFIG_ROOT_DIR/$1/wpa_cipher	
		echo "3" > $CONFIG_ROOT_DIR/$1/wpa2_cipher
	fi	
elif [ "${AuthMode}" = "WPAPSKWPA2PSK" ]; then
	echo "6" > $CONFIG_ROOT_DIR/$1/encrypt
	echo "0" > $CONFIG_ROOT_DIR/$1/enable_1x	
	echo "2" > $CONFIG_ROOT_DIR/$1/auth_type	
	if [ "${EncrypType}" = "AES" ]; then
		echo "2" > $CONFIG_ROOT_DIR/$1/wpa_cipher	
		echo "2" > $CONFIG_ROOT_DIR/$1/wpa2_cipher
	elif [ "${EncrypType}" = "TKIP" ]; then
		echo "1" > $CONFIG_ROOT_DIR/$1/wpa_cipher	
		echo "1" > $CONFIG_ROOT_DIR/$1/wpa2_cipher
	elif [ "${EncrypType}" = "TKIPAES" ]; then
		echo "3" > $CONFIG_ROOT_DIR/$1/wpa_cipher	
		echo "3" > $CONFIG_ROOT_DIR/$1/wpa2_cipher
	fi	
fi

echo "$WPAPSK" > $CONFIG_ROOT_DIR/$1/wpa_psk

echo 2 > $CONFIG_ROOT_DIR/$1/wpa_auth

if [ $1 = "wlan0-va1" ]; then
	eap_set_paras $1
fi
}


echo "<<<  tz_mutil_ssid.sh   >>>"
echo 1 > $CONFIG_ROOT_DIR/wlan0-va0/wlan_disabled
echo 1 > $CONFIG_ROOT_DIR/wlan0-va1/wlan_disabled
echo 1 > $CONFIG_ROOT_DIR/wlan0-va2/wlan_disabled

if [ "$TZ_MAINSSID_ENABLE" == "1" ]; then
	if [ "${TZ_SSID2_ENABLE}" = "yes" -o "${TZ_SSID2_ENABLE}" = "1" ]; then
		multissid_set_paras wlan0-va0
	fi

	if [ "${TZ_SSID3_ENABLE}" = "yes" -o "${TZ_SSID3_ENABLE}" = "1" ]; then
		multissid_set_paras wlan0-va1
	fi
	
	if [ "${TZ_SSID4_ENABLE}" = "yes" -o "${TZ_SSID4_ENABLE}" = "1" ]; then
		multissid_set_paras wlan0-va2
	fi
fi
