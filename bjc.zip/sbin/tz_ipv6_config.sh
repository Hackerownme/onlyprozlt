#!/bin/sh 
#set -x

####��ȡͨ��nv����####
path_sh=`nv get path_sh`
path_conf=`nv get path_conf`
test_log=`nv get path_log`"te.log"
path_tmp=`nv get path_tmp`
path_ro=`nv get path_ro`

if [ "-$1" == "-3" ]; then
	lan_if="wlan0-va0"
elif [ "-$1" == "-4" ];then
	lan_if="wlan0-va1"
else
	exit 1
fi

echo "input param is $1"
echo "Info: tz_ipv6_config.sh $1 start" >> $test_log

wan_addr_temp=`nv get $wan_if"ipv6_wan_ipaddr"`
wan_addr=`echo $wan_addr_temp | sed 's/\/64//'`

prefix_len=64

b_dhcpv6stateEnabled=`nv get dhcpv6stateEnabled`
b_dhcpv6statelessEnabled=`nv get dhcpv6statelessEnabled`


############# ��ȡ�����������Ϣ ############
get_wan_info()
{
	wan_if=wan$1
	wan_addr=`nv get $wan_if"_ipv6_ip"`

	#��Ҫ�õ���������ļ�
	dhcp6s_conf=$path_conf/dhcp6s_$wan_if.conf
	radvd_conf=$path_conf/radvd_$wan_if.conf
	radvd_pidfile=$path_tmp/radvd_$wan_if.pid

}

#############linkup  dhcpserver set############
linkup_add_dns_to_dhcp6s_radvd_conf()
{
    # ipv6 dns set
    ipv6_dns_mode=`nv get pswan_ipv6_dns_mode`
    echo "ipv6_dns_mode:$ipv6_dns_mode"
    echo "the input param  is $1"
    
    ipv6_prefer_dns=""
    ipv6_standby_dns=""
    if [ "-$ipv6_dns_mode" = "-auto" ];then
     
          ipv6_pridns_auto=`nv get $wan_if"_ipv6_pridns_auto"`
          ipv6_secdns_auto=`nv get $wan_if"_ipv6_secdns_auto"`
          
            if [ -n "$ipv6_pridns_auto" ] && [ "-$ipv6_pridns_auto" != "-::" ] && [ "-$ipv6_pridns_auto" != "-::0" ];then
                ipv6_prefer_dns=$ipv6_pridns_auto
            fi
            
            if [ -n "$ipv6_secdns_auto" ] && [ "-$ipv6_secdns_auto" != "-::" ] && [ "-$ipv6_secdns_auto" != "-::0" ];then
                ipv6_standby_dns=$ipv6_secdns_auto
            fi

    elif [ "-$ipv6_dns_mode" = "-manual" ];then
            #�����ֶ�DNS��ҳ��ֻ�����õ�pswan�ڣ����Զ����ֶ�dns�����ܺ���ģʽ����ʱ��ȡ��pswan���ֶ�dns��ַ
            ipv6_pridns_manual=`nv get $pswan_if_name"_ipv6_pridns_manual"`
            ipv6_secdns_manual=`nv get $pswan_if_name"_ipv6_secdns_manual"`
            
            if [ -n "$ipv6_pridns_manual" ] && [ "-$ipv6_pridns_manual" != "-::" ] && [ "-$ipv6_pridns_manual" != "-::0" ];then
                ipv6_prefer_dns=$ipv6_pridns_manual
            fi
            
            if [ -n "$ipv6_secdns_manual" ] && [ "-$ipv6_secdns_manual" != "-::" ] && [ "-$ipv6_secdns_manual" != "-::0" ];then
                ipv6_standby_dns=$ipv6_secdns_manual
            fi
            
      fi

    if [ "-$ipv6_prefer_dns" == "-" -a "-$ipv6_standby_dns" == "-" ]; then
        return
    else
        if [ -n "$1" ] && [ "$1" == "dhcp6s" ] ;then
            echo -e "\toption dns_servers $ipv6_prefer_dns $ipv6_standby_dns;" >> $dhcp6s_conf
        elif [ -n "$1" ] && [ "$1" == "radvd" ] ;then
            # del last line
            sed -i '$d' $radvd_conf
            echo -e "\tRDNSS $ipv6_prefer_dns $ipv6_standby_dns\n\t{" >> $radvd_conf
            echo -e "\t\tAdvRDNSSPreference 15;" >> $radvd_conf
            echo -e "\t\tAdvRDNSSOpen on;" >> $radvd_conf
            echo -e "\t};\n};" >> $radvd_conf
        fi
    fi
}

linkup_dhcpv6_server_set()
{
	pid=$(ps | grep $dhcp6s_conf | grep -v grep | awk '{print $1}')
	if [ "-$pid" != "-" ];then	
		kill -9 $pid
	fi

	rm -fr $dhcp6s_conf

	ipv6_addr_conver "$wan_addr" "$wan_if"
	dhcpv6_start=`nv get $wan_if"_dhcpv6_start"`
	dhcpv6_end=`nv get $wan_if"_dhcpv6_end"`
	echo -e "interface $lan_if {" > $dhcp6s_conf
	#set up dhcpv6 addr pool
	if [ "-$b_dhcpv6stateEnabled" = "-1" ];then
		echo -e "\tserver-preference 255;\n\trenew-time 6000;" >> $dhcp6s_conf
		echo -e "\trebind-time 9000;\n\tprefer-life-time 1300;" >> $dhcp6s_conf
		echo -e "\tvalid-life-time 2000;\n\tallow rapid-commit;" >> $dhcp6s_conf
		echo -e "\tlink $lan_if {\n\t\tallow unicast;\n\t\tsend unicast;" >> $dhcp6s_conf
		echo -e "\t\tpool {\n\t\t\trange $dhcpv6_start to $dhcpv6_end/$prefix_len;" >> $dhcp6s_conf
		echo -e "\t\t};\n\t};" >> $dhcp6s_conf
		linkup_add_dns_to_dhcp6s_radvd_conf dhcp6s
		echo -e "};" >> $dhcp6s_conf
		dhcp6s -dDf -c $dhcp6s_conf $lan_if &
	else
		if [ "-$b_dhcpv6statelessEnabled" = "-1" ];then
			echo -e "\tlink $lan_if {\n\t};" >> $dhcp6s_conf
			linkup_add_dns_to_dhcp6s_radvd_conf dhcp6s
			echo -e "};" >> $dhcp6s_conf
			dhcp6s -dDf -c $dhcp6s_conf $lan_if &
		fi
	fi
}

#############linkup  radvd set############
linkup_radvd_set() 
{
	echo  "enter linkup_radvd_set "
	pid=$(ps | grep $radvd_conf | grep -v grep | awk '{print $1}')
	if [ "-$pid" != "-" ];then	
		kill -9 $pid
	fi

	pid=$(ps | grep $radvd_conf | grep -v grep | awk '{print $1}')
	if [ "-$pid" != "-" ];then	
		kill -9 $pid
	fi

	rm -rf $radvd_conf
	#wangming delete
	if [ "-$b_dhcpv6stateEnabled" = "-1" ];then
	echo -e "interface $lan_if\n{\n\tAdvSendAdvert on;" > $radvd_conf
	echo -e "\tAdvManagedFlag on;\n};" >> $radvd_conf
	rm -rf $radvd_pidfile
	radvd -d 3 -C $radvd_conf -p $radvd_pidfile &
	echo  "leave linkup_radvd_set "
	return
	fi

	cp $path_ro/radvd_template.conf $radvd_conf
	sed -i -e s/interface\ br0/interface\ $lan_if/g $radvd_conf
	sed  -i -e 's/#ipv6_wan_addr#\/64/#ipv6_wan_addr#\/#prefix_len#/g' $radvd_conf
	sed  -i -e s/#ipv6_wan_addr#/$wan_addr/g $radvd_conf 
	sed  -i -e s/#prefix_len#/$prefix_len/g $radvd_conf
	sed  -i -e s/#adv_switch#/on/g $radvd_conf 

	echo "copy radvd_template.conf"
	echo "wan_addr:$wan_addr"
	echo "prefix_len:$prefix_len"

	#slaac with dns info
	if [ "-$b_dhcpv6statelessEnabled" = "-1" ];then
	echo "use dhcpv6stateless for dns"
	else
	sed -i -e 's/AdvOtherConfigFlag on;/AdvOtherConfigFlag off;/g' $radvd_conf
	linkup_add_dns_to_dhcp6s_radvd_conf radvd
	fi


	#sleep 1
	rm -rf $radvd_pidfile
	radvd -d 3 -C $radvd_conf -p $radvd_pidfile &

	echo  "leave linkup_radvd_set "
}

############ipv6 shell entry#################
get_wan_info $1
linkup_dhcpv6_server_set
linkup_radvd_set
