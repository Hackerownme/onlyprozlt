#!/bin/sh



CONFIG_ROOT_DIR="/wifi/realtek/rtl8192c"

TZ_SSID2_ENABLE=`nv get tz_ssid2_enable`
TZ_SSID3_ENABLE=`nv get tz_ssid3_enable`
TZ_SSID4_ENABLE=`nv get tz_ssid4_enable`
TZ_MULTIDHCP_ENABLE=`nv get tz_multidhcp_enable`
TZ_DHCP2_ENABLE=`nv get tz_dhcp2_enable`
TZ_DHCP3_ENABLE=`nv get tz_dhcp3_enable`
TZ_DHCP4_ENABLE="0"
TZ_MAINSSID_ENABLE=`nv get wifiEnabled`


va0_netmask=`nv get va0_netmask`
va0_ipaddr=`nv get va0_ipaddr`
va1_netmask=`nv get va1_netmask`
va1_ipaddr=`nv get va1_ipaddr`


va_addto_br0()
{
	if [ "x$TZ_MULTIDHCP_ENABLE" == "x1" ] && [ "$2" != "wlan0-va2" ]; then
		brctl delif br0 $2
		if [ "x$2" == "xwlan0-va0" ]; then
			ifconfig wlan0-va0 $va0_ipaddr netmask $va0_netmask
		else
			ifconfig wlan0-va1 $va1_ipaddr netmask $va1_netmask
		fi
	else
		brctl addif br0 $2
		echo "tz_multi_ssid_bridge.sh brctl addif br0 $2"
	fi
}



echo "<<<  tz_multi_ssid_bridge.sh   >>>"

if [ "$TZ_MAINSSID_ENABLE" == "1" ]; then
	if [ "${TZ_SSID2_ENABLE}" = "yes" -o "${TZ_SSID2_ENABLE}" = "1" ]; then
		echo "ifconfig wlan0-va0 up"
		ifconfig wlan0-va0 up
		va_addto_br0 ${TZ_DHCP2_ENABLE} wlan0-va0
	else
		echo "ifconfig wlan0-va0 down"
		ifconfig wlan0-va0 down
	fi

	if [ "${TZ_SSID3_ENABLE}" = "yes" -o "${TZ_SSID3_ENABLE}" = "1" ]; then
		echo "ifconfig wlan0-va1 up"
		ifconfig wlan0-va1 up
		va_addto_br0 ${TZ_DHCP3_ENABLE} wlan0-va1
	else
		echo "ifconfig wlan0-va1 down"
		ifconfig wlan0-va1 down
	fi
	
	if [ "${TZ_SSID4_ENABLE}" = "yes" -o "${TZ_SSID4_ENABLE}" = "1" ]; then
		echo "ifconfig wlan0-va2 up"
		ifconfig wlan0-va2 up
		va_addto_br0 ${TZ_DHCP4_ENABLE} wlan0-va2
	else
		echo "ifconfig wlan0-va2 down"
		ifconfig wlan0-va2 down
	fi
fi
